import openpyxl
import math
import random

# Load the workbook
wb = openpyxl.load_workbook('restoran.xlsx')
sheet = wb.active

# Assume first row is header, columns: ID, pelayanan, harga
data = []
for row in sheet.iter_rows(min_row=2, values_only=True):
    if row[0] is not None:
        data.append({'id': row[0], 'pelayanan': row[1], 'harga': row[2]})

# Fuzzification: Normalize the values to [0,1] for pelayanan and harga
# Find min and max for normalization
pelayanan_values = [d['pelayanan'] for d in data]
harga_values = [d['harga'] for d in data]
min_pelayanan = min(pelayanan_values)
max_pelayanan = max(pelayanan_values)
min_harga = min(harga_values)
max_harga = max(harga_values)

# Inference: Compute fuzzy membership degrees for pelayanan (higher better) and harga (lower better)
for d in data:
    # Pelayanan: higher better
    d['score_pelayanan'] = (d['pelayanan'] - min_pelayanan) / (max_pelayanan - min_pelayanan) if max_pelayanan != min_pelayanan else 1
    # Harga: lower better
    d['score_harga'] = (max_harga - d['harga']) / (max_harga - min_harga) if max_harga != min_harga else 1
    # Defuzzification: Combine the fuzzy scores into a crisp total score using average
    d['total_score'] = (d['score_pelayanan'] + d['score_harga']) / 2

# Sort by total_score descending
data.sort(key=lambda x: x['total_score'], reverse=True)

# Get top 5 IDs
top_5 = [d['id'] for d in data[:5]]

# Output to Excel file "ranking.xlsx"
wb_ranking = openpyxl.Workbook()
sheet_ranking = wb_ranking.active
sheet_ranking.title = "Ranking"
sheet_ranking['A1'] = "ID"
sheet_ranking['B1'] = "Pelayanan"
sheet_ranking['C1'] = "Harga"
sheet_ranking['D1'] = "Total Score"
for i, d in enumerate(data[:5], start=2):
    sheet_ranking[f'A{i}'] = d['id']
    sheet_ranking[f'B{i}'] = d['pelayanan']
    sheet_ranking[f'C{i}'] = d['harga']
    sheet_ranking[f'D{i}'] = d['total_score']
wb_ranking.save('ranking.xlsx')